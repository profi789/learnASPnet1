﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExportDemo.Models
{
    public class CustomerViewModel
    {
        public int CustomerID { get; set; }
        public string CustomerName{ get; set; }
        public string Location { get; set; }
        public string PrimaryBusiness { get; set; }
    }
}