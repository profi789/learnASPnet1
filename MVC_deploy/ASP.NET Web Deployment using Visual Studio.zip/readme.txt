These projects are for use with the deployment tutorial located at:
http://asp.net/web-forms/tutorials/deployment/visual-studio-web-deployment/introduction